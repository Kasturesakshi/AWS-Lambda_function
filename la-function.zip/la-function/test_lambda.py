import lambda_function

# Define the event (input) to simulate the Lambda environment
event = {
    "num1": 5,
    "num2": 10
}

# Context is optional for local testing and can be left as None
context = None

# Call the Lambda function and print the result
response = lambda_function.lambda_handler(event, context)
print("Response:", response)
